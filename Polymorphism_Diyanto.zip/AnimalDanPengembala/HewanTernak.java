public abstract class HewanTernak{
	public abstract void bersuara();
}