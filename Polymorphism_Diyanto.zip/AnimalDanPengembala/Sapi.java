public class Sapi extends HewanTernak{
	public void bersuara(){
		System.out.println("Moooo...");
	}
} 