public class Ayam extends HewanTernak{
	public void bersuara(){
		System.out.println("Kokok...");
	}
	public int bertelur(int nilai){
		return nilai;
	}
} 