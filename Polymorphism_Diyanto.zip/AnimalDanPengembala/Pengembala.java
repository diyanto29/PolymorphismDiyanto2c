public class Pengembala{
	HewanTernak ht;

	public void menyapa(HewanTernak ht){
		this.ht=ht;
	}
	public void setMendengar(){
		ht.bersuara();
	}
}