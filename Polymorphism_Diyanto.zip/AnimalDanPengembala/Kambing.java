public class Kambing extends HewanTernak{
	public void bersuara(){
		System.out.println("Mbe...");
	}
} 